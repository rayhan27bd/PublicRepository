﻿namespace AttendanceSystem.Entities
{
    public enum UserType
    {
        Admin = 10,
        Teacher = 20,
        Student = 30,
    }
}
