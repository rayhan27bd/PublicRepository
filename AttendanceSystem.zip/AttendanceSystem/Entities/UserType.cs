﻿using System;
using System.Text;

namespace AttendanceSystem.Entities
{
    public enum UserType
    {
        Admin = 10,
        Teacher = 20,
        Student = 30,
    }
}
